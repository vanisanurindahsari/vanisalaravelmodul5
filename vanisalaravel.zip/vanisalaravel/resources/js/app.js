import './bootstrap';
import.meta.glob(["../images/**"]);
@import "bootstrap-icons/font/bootstrap-icons.css";
